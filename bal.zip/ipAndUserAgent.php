<?php
$ip = $_SERVER["REMOTE_ADDR"];
$agent = htmlspecialchars($_SERVER["HTTP_USER_AGENT"]);
 ?>
