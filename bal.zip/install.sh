#!/bin/bash

banner() {
    echo "c2";
}

isRoot() {
    if [ "$EUID" -ne 0 ]; then
        echo -e "\n[!] Please run the script with root privileges.\n"
        exit
    fi
}

checkInternet() {
    wget -q --spider http://www.google.co.in
    if [ $? -ne 0 ]; then
        echo -e "\n[!] Please check your internet connection.\n"
        exit
    fi
}

checkOS() {
    . /etc/os-release -r
    if [ "$NAME" == "Ubuntu" ]; then
        OS="ubuntu"
    elif [ "$NAME" == "Kali GNU/Linux" ]; then
        OS="kali/parrot"
    elif [ "$NAME" == "Parrot GNU/Linux" ]; then
        OS="kali/parrot"
    else
        echo -e "\n[!] Your OS is detected as: $NAME\n"
        echo "      > Which is not supported for this installation script."
        echo -e "      > Please refer to Wiki Page for proper installation on your system.\n"
        exit
    fi
}

installPackages() {
    echo -e "\n[*] Starting to install required packages.\n"
    sleep 3
    DEBIAN_FRONTEND=noninteractive apt install apache2 php libapache2-mod-php php-mysql mysql-server -y
}

configure() {
    clear
    banner
    echo -e "\n[+] Packages are installed."
    sleep 1
    echo -e "\n[!] This script will remove all files in /var/www/html/ on your system.\n"
    read -p "    Are you willing to continue? (y/n): " CHOICE
    if [ "$CHOICE" != "y" ]; then
        echo -e "\n[*] Exiting.\n"
        exit
    fi
    echo -e "\n[*] Please insert configuration data:\n"
    TTY=$(/usr/bin/tty)
    read -p "       Database Name       : " NSDBNAME < $TTY
    read -s -p "       Mysql Root Password : " NSDBPASS < $TTY
    echo ""
    read -p "       Web Panel Username  : " NSPANELUSER < $TTY
    read -s -p "       Web Panel Password  : " NSPANELPASS < $TTY
    echo -e "\n[*] Configuring... please wait.\n"
    sed -i '5 s/ = ".*/ = "'"root"'";/' conn.php
    sed -i '6 s/ = ".*/ = "'"$NSDBPASS"'";/' conn.php
    sed -i '7 s/ = ".*/ = "'"$NSDBNAME"'";/' conn.php
    systemctl start mysql
    if [ "$OS" == "ubuntu" ]; then
        mysql <<QUERY
        ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '${NSDBPASS}';
QUERY
    elif [ "$OS" == "kali/parrot" ]; then
        mysql <<QUERY
        ALTER USER 'root'@'localhost' IDENTIFIED BY '${NSDBPASS}';
QUERY
    fi
    mysql -u root -p${NSDBPASS} -h localhost > /dev/null 2>&1 <<QUERY
    CREATE DATABASE $NSDBNAME;
    USE $NSDBNAME;
    source balajic2.sql
    INSERT INTO users(username,password) values('$NSPANELUSER', MD5('BalaJi${NSPANELPASS}iJalaB'));
QUERY
    rm -rf /var/www/html/*
    cp -r * /var/www/html/
    chown -R www-data:www-data /var/www/html/
    echo -e "\n[mysqld]\nbind-address = 127.0.0.1\nskip-networking" >>/etc/mysql/my.cnf
    sed -i 's/Options Indexes FollowSymLinks/Options -Indexes/' /etc/apache2/apache2.conf
    systemctl restart mysql
    systemctl restart apache2
    systemctl enable mysql > /dev/null 2>&1
    systemctl enable apache2 > /dev/null 2>&1
    clear
    banner
    echo -e "\n[+] Installation completed.\n"
    sleep 1
    echo -e "[*] You can login and start using your panel at: localhost/getin.php\n"
    sleep 1
    echo -e "              ☆  ☆               \n"
}

clear
banner
isRoot
checkOS
checkInternet
installPackages
configure
